package codes.blitz.game.generated;

public interface Action {
  ActionType type();
}
