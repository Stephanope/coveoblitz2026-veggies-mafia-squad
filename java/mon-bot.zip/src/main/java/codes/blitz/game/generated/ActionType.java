package codes.blitz.game.generated;

public enum ActionType {
  SPORE_MOVE,
  SPORE_MOVE_TO,
  SPORE_CREATE_SPAWNER,
  SPAWNER_PRODUCE_SPORE,
  SPORE_SPLIT,
}
