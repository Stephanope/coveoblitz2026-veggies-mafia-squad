package codes.blitz.game.bot;
import codes.blitz.game.generated.*;

public record Nutrient(Position position, int value) {}
